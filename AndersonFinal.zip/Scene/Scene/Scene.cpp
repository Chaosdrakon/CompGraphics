#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <cstdlib>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <windows.h>  
#include <GL/glut.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 600

void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

int main(void)
{
	GLFWwindow* window;

	if (!glfwInit())
	{
		return -1;
	}

	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Daniel Anderson", NULL, NULL);

	int screenWidth, screenHeight;
	glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);

	glViewport(0.0f, 0.0f, screenWidth, screenHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, 0, 600);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Movement
	GLfloat cameraSpeed = 3.0f; // Camera Speed
	GLfloat lastX = 400, lastY = 300; //Starting Point
	bool firstMouseMove = true; //Intial movement

	class Camera {
	public:
		// camera properties 
		glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
		glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
		glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

		bool firstMouse = true;
		float yaw = -90.0f;
		float pitch = 0.0f;
		float lastX = 800.0f;
		float lastY = 600.0f;
		float fov = 45.0;

		float deltaTime = 0.0f;
		float lastFrame = 0.0f;


		Camera(glm::vec3 position, glm::vec3 up, glm::vec3 right, glm::vec3 front) {
			this->position = position;
			this->up = up;
			this->right = right;
			this->front = front;
			this->worldUp = worldUp;
		}

		//Camera Vector
		void updateCameraVectors() {

			glm::vec3 front;
			front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
			front.y = sin(glm::radians(pitch));
			front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
			this->front = glm::normalize(front);


			this->right = glm::normalize(glm::cross(this->front, this->worldUp));
			this->up = glm::normalize(glm::cross(this->right, this->front));
		}

		//Keyboard input
		void processKeyboardInput(GLFWwindow* window) {
			// Move forward
			if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
				this->position += this->front * cameraSpeed * deltaTime;
			}
			// Move backward
			if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
				this->position -= this->front * cameraSpeed * deltaTime;
			}
			// Move left
			if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
				this->position -= this->right * cameraSpeed * deltaTime;
			}
			// Move right
			if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
				this->position += this->right * cameraSpeed * deltaTime;
			}
			// Move up
			if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
				this->position += this->up * cameraSpeed * deltaTime;
			}
			// Move down
			if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
				this->position -= this->up * cameraSpeed * deltaTime;
			}
		}
		bool UCreateTexture(const char* filename, GLuint& textureId)
		{
			int width, height, channels;
			unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
			if (image)
			{
				flipImageVertically(image, width, height, channels);

				glGenTextures(1, &textureId);
				glBindTexture(GL_TEXTURE_2D, textureId);

				// set the texture wrapping parameters
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
				// set texture filtering parameters
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

				if (channels == 3)
					glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
				else if (channels == 4)
					glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
				else
				{
					cout << "Not implemented to handle image with " << channels << " channels" << endl;
					return false;
				}

				glGenerateMipmap(GL_TEXTURE_2D);

				stbi_image_free(image);
				glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

				return true;
			}

			// Error loading the image
			return false;
		}

		// Mouse input
		void processMouseInput(GLFWwindow* window) {
			double xpos, ypos;
			glfwGetCursorPos(window, &xpos, &ypos);
			if (firstMouseMove) {
				lastX = xpos;
				lastY = ypos;
				firstMouseMove = false;
			}

			GLfloat xoffset = xpos - lastX;
			GLfloat yoffset = ypos - lastY;
			lastX = xpos;
			lastY = ypos;

			GLfloat sensitivity = 0.05f;
			xoffset *= sensitivity;
			yoffset *= sensitivity;

			yaw += xoffset;
			pitch += yoffset;

			if (pitch > 89.0f) {
				pitch = 89.0f;
			}


	//Base Start
	GLfloat b[] = { //First Triangle front face of base
		0,550,0, //B1
		0,600,0, //B6
		1000,600,0,  //B5
	};

	GLfloat b1[] = { //Second Triangle front face of base
		0,550,0, //B1
		1000,550,0, //B4
		1000,600,0,  //B5
	};

	GLfloat b2[] = { //First Triangle of Right face of base
		1000,550,0, //B4
		1000,600,0, //B5
		1000,550,200,  //B3
	};

	GLfloat b3[] = { //Second Triangle of Right face of base
		1000,550,200, //B3
		1000,600,0, //B5
		1000,600,200, //B7
	};

	GLfloat b4[] = { //First Triangle of Back face of base
		1000,550,200, //B3
		1000,600,200, //B7
		0,550,200, //B2
	};

	GLfloat b5[] = { //Second Triangle of back face of base
		0,550,200, //B2
		0,600,200, //B8
		1000,600,200, //B7
	};

	GLfloat b6[] = { //First Triangle of left face of base
		0,550,0,//B1
		0,600,0,//B6
		0,550,200,//B2
	};

	GLfloat b7[] = { //Second Triangle of left face of base
		0,550,0, //B1
		0,550,200, //B2
		0,600,200, //B8
	};

	GLfloat b8[] = { //First Triangle of top face of base
		0,550,0, //B1
		0,550,200, //B2
		1000,550,0, //B4
	};

	GLfloat b9[] = { //Second Triangle of top face of base
		0,550,200, //B2
		1000,550,200, //B3
		100,550,0, //B4
	};

	GLfloat b10[] = { //First Triangle of bottom face of base
		0,600,0, //B6
		0,600,200, //B8
		1000,600,0, //B5
	};

	GLfloat b11[] = { //Second Triangle of bottom face of base
		0,600,200, //B8
		1000,600,0, //B5
		1000,600,200, //B7
	};
	//Base finished

	//Cube Start
	GLfloat c[] = {//First triangle of front face of cube
		250,550,50, //C1
		250,450,50, //C2
		450,550,50 //C3
	};

	GLfloat c1[] = {//Second Triangle of front face
		250,450,50, //C2
		450,450,50, //C4
		450,550,50, //C3
	};

	GLfloat c2[] = {//First Triangle right face
		450,450,50, //C4
		450,550,50, //C3
		450,550,100, //C6
	};

	GLfloat c3[] = {//Second triangle right face
		450,450,50, //C4
		450,450,100, //C5
		450,550,100, //C6
	};

	GLfloat c4[] = {//First triangle rear face
		250,450,100, //C8
		450,450,100, //C5
		450,550,100, //C6
	};

	GLfloat c5[] = {//Second triangle rear face
		250,450,100, //C8
		450,550,100, //C6
		250,550,100, //C7
	};

	GLfloat c6[] = {//First triangle left face
		250,450,50, //C2
		250,550,50, //C1
		250,550,100, //C7
	};

	GLfloat c7[] = {//Second Triangle left face
		250,450,50, //C2
		250,450,100, //C8
		250,550,100, //C7
	};

	GLfloat c8[] = {//First Triangle top face
		250,450,50, //C2
		450,450,50, //C4
		250,450,100, //C8
	};

	GLfloat c9[] = {//Second Triangle top face
		250,450,100, //C8
		450,450,100, //C5
		450,450,50, //C4
	};

	GLfloat c10[] = {//First Triangle bottom face
		250,550,50, //C1
		250,550,100, //C7
		450,550,50, //C3
	};

	GLfloat c11[] = {//Second Triangle bottom face
		250,550,100, //C7
		450,550,100, //C6
		450,550,50, //C3
	};
	//Cube Finished

	//Pyramid Start
	GLfloat p[] = {//Front Face
		250,450,50, //P1
		450,450,50, //P2
		350,400,75, //P5
	};

	GLfloat p1[] = {//Right Face
		450,450,50, //P2
		450,450,100, //P3
		350,400,75, //P5
	};

	GLfloat p2[] = {//Rear Face
		450,450,100, //P3
		250,450,100, //P4
		350,400,75, //P5
	};

	GLfloat p3[] = {//Left Face
		250,450,50, //P1
		250,450,100, //P4
		350,400, 75, //P5
	};

	GLfloat p4[] = {//First Triangle bottom face
		250,450,50, //P1
		250,450,100, //P4
		450,450,50, //P2
	};

	GLfloat p5[] = {//Second Triangle bottom face
		250,450,100, //P4
		450,450,100, //P3
		450,450,50, //P2
	};
	//Pyramid Finished


	//Cylinder Start

	GLfloat o[] = {//First section bottom base
		550, 550, 50, //C1
		600, 550, 50, //C2
		575, 550, 65, //C3
	};

	GLfloat o1[] = { //Second section bottom base
		600, 550, 50, //C2
		650, 550, 60, //C4
		575, 550, 65, //C3
	};

	GLfloat o2[] = {// Third Section base
		650, 550, 60, //C4
		650, 550, 70, //C5
		575, 550, 65, //C3
	};

	GLfloat o3[] = {//Fourth Section
		650, 550, 70, //C5
		600, 550, 80, //C6
		575, 550, 65, //C3
	};

	GLfloat o4[] = {//Fifth section
		600, 550, 80, //C6
		550, 550, 80, //C7
		575, 550, 65, //C3
	};

	GLfloat o5[] = {//Sixth section
		550, 550, 80, //C7
		500, 550, 70, //C8
		575, 550, 65, //C3
	};

	GLfloat o6[] = {//Seventh Section
		500, 550, 70, //C8
		500, 550, 60, //C9
		575, 550, 65, //C3
	};

	GLfloat o7[] = {//Eight Section
		500, 550, 60, //C9
		550, 550, 50, //C1
		575, 550, 65, //C3
	};

	GLfloat to[] = {//First section Top base
		550, 350, 50, //TC1
		600, 350, 50, //TC2
		575, 350, 65, //TC3
	};

	GLfloat to1[] = { //Second section base
		600, 350, 50, //TC2
		650, 350, 60, //TC4
		575, 350, 65, //TC3
	};

	GLfloat to2[] = {// Third Section base
		650, 350, 60, //TC4
		650, 350, 70, //TC5
		575, 350, 65, //TC3
	};

	GLfloat to3[] = {//Fourth Section
		650, 350, 70, //TC5
		600, 350, 80, //TC6
		575, 350, 65, //TC3
	};

	GLfloat to4[] = {//Fifth section
		600, 350, 80, //TC6
		550, 350, 80, //TC7
		575, 350, 65, //TC3
	};

	GLfloat to5[] = {//Sixth section
		550, 350, 80, //TC7
		500, 350, 70, //TC8
		575, 350, 65, //TC3
	};

	GLfloat to6[] = {//Seventh Section
		500, 350, 70, //TC8
		500, 350, 60, //TC9
		575, 350, 65, //TC3
	};

	GLfloat to7[] = {//Eight Section
		500, 350, 60, //TC9
		550, 350, 50, //TC1
		575, 350, 65, //TC3
	};

	GLfloat cos[] = {//Outside Side 1
		550, 350, 50, //TC1
		600, 350, 50, //TC2
		550, 550, 50, //C1
	};

	GLfloat cos1[] = {//Outside 2
		550, 550, 50, //C1
		600, 550, 50, //C2
		600, 350, 50, //TC2
	};

	GLfloat cos2[] = {
		600, 550, 50, //C2
		600, 350, 50, //TC2
		650, 550, 60, //C4
	};

	GLfloat cos3[] = {
		600, 350, 50, //TC2
		650, 550, 60, //C4
		650, 350, 60, //TC4
	};

	GLfloat cos4[] = {
		650, 550, 60, //C4
		650, 350, 60, //TC4
		650, 550, 70, //C5
	};

	GLfloat cos5[] = {
		650, 350, 60, //TC4
		650, 550, 70, //C5
		650, 350, 70, //TC5
	};

	GLfloat cos6[] = {
		650, 550, 70, //C5
		650, 350, 70, //TC5
		600, 550, 80, //C6
	};

	GLfloat cos7[] = {
		650, 350, 70, //TC5
		600, 550, 80, //C6
		600, 350, 80, //TC6
	};

	GLfloat cos8[] = {
		600, 550, 80, //C6
		600, 350, 80, //TC6
		550, 550, 80, //C7
	};

	GLfloat cos9[] = {
		600, 350, 80, //TC6
		550, 550, 80, //C7
		550, 350, 80, //TC7
	};

	GLfloat cos10[] ={
		550, 550, 80, //C7
		550, 350, 80, //TC7
		500, 550, 70, //C8
	};

	GLfloat cos11[] = {
		550, 350, 80, //TC7
		500, 550, 70, //C8
		500, 350, 70, //TC8
	};

	GLfloat cos12[] = {
		500, 550, 70, //C8
		500, 350, 70, //TC8
		500, 550, 60, //C9
	};

	GLfloat cos13[] = {
		500, 350, 70, //TC8
		500, 550, 60, //C9
		500, 350, 60, //TC9
	};

	GLfloat cos14[] = {
		500, 550, 60, //C9
		500, 350, 60, //TC9
		550, 550, 50, //C1
	};

	GLfloat cos15[] = {
		500, 350, 60, //TC9
		550, 550, 50, //C1
		550, 350, 50, //TC1
	};

	//Cylinder Finish


	GLfloat color[] = {//Base color
		149,69,53, //Color = "Chestnut"
		149,69,53,
		149,69,53,
	};

	GLfloat color1[] = {//Cube color
		0,0,255, //Color = "Blue"
		0,0,255,
		0,0,255,
	};

	GLfloat color2[] = {//Pyramid Color
		0,110,51, //Color = "Forest Green"
		0,110,51,
		0,110,51,
	};

	GLfloat color3[] = {//Cylinder Color
		255, 191, 0, //Color = "Amber"
		255, 191, 0,
		255, 191, 0,
	};

	while (!glfwWindowShouldClose(window)) {
		glClear(GL_COLOR_BUFFER_BIT);

		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_COLOR_ARRAY);

		//Draw and color base
		glVertexPointer(3, GL_FLOAT, 0, b);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b1);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b2);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b3);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b4);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b5);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b6);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b7);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b8);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b9);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b10);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, b11);
		glColorPointer(3, GL_FLOAT, 0, color);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		//Base finished

		//Cube Draw and Color
		glVertexPointer(3, GL_FLOAT, 0, c);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c1);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c2);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c3);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c4);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c5);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c6);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c7);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c8);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c9);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c10);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, c10);
		glColorPointer(3, GL_FLOAT, 0, color1);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		//Cube Finished

		//Pyramid Start
		glVertexPointer(3, GL_FLOAT, 0, p);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, p1);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, p2);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, p3);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, p4);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, p5);
		glColorPointer(3, GL_FLOAT, 0, color2);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		//Pyrmid Finish

		//Cylinder Start

		glVertexPointer(3, GL_FLOAT, 0, o);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o1);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o2);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o3);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o4);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o5);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o6);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, o7);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to1);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to2);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to3);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to4);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to5);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to6);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, to7);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos1);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos2);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos3);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos4);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos5);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos6);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos7);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos8);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos9);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos10);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos11);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos12);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos13);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos14);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glVertexPointer(3, GL_FLOAT, 0, cos15);
		glColorPointer(3, GL_FLOAT, 0, color3);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		//Cynlider Finish


		glfwSwapBuffers(window);
		string vertexShaderSource =
			"#version 330 core\n"
			"layout(location = 0) in vec4 vPosition;"
			"layout(location = 1) in vec4 aColor;"
			"out vec4 oColor;"
			"uniform mat4 model;"
			"uniform mat4 view;"
			"uniform mat4 projection;"
			"void main()\n"
			"{\n"
			"gl_Position =  projection * view * model * vPosition;"
			"oColor = aColor;"
			"}\n";

		// Fragment shader source code
		string fragmentShaderSource =
			"#version 330 core\n"
			"in vec4 oColor;"
			"out vec4 fragColor;"
			"void main()\n"
			"{\n"
			"fragColor = oColor;"
			"}\n";

		// Creating Shader Program
		GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
		GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);


		while (!glfwWindowShouldClose(window))
		{
			glfwGetFramebufferSize(window, &width, &height);
			glViewport(0, 0, width, height);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glUseProgram(shaderProgram);
			glm::mat4 viewMatrix;
			glm::mat4 projectionMatrix;
			viewMatrix = glm::translate(viewMatrix, glm::vec3(0.0f, 0.0f, -3.0f));
			viewMatrix = glm::rotate(viewMatrix, 45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


			projectionMatrix = glm::perspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
			GLuint modelLoc = glGetUniformLocation(shaderProgram, "model");
			GLuint viewLoc = glGetUniformLocation(shaderProgram, "view");
			GLuint projectionLoc = glGetUniformLocation(shaderProgram, "projection");
			glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
			glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
			glBindVertexArray(VAO); // User-defined VAO must be called before draw. 

			for (GLuint i = 0; i < 4; i++)
			{
				glm::mat4 modelMatrix;
				modelMatrix = glm::translate(modelMatrix, planePositions[i]);
				modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
				modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
				glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
				draw();
			}

			glBindVertexArray(0);
			glUseProgram(0);
			glfwSwapBuffers(window);
			glfwPollEvents();
		}
		glDeleteVertexArrays(1, &VAO);
		glDeleteBuffers(1, &VBO);
		glDeleteBuffers(1, &EBO);
		glfwTerminate();
		return 0;
	}

	return 0;
}
